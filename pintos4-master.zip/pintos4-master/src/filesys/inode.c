#include "filesys/inode.h"
#include <debug.h>
#include <round.h>
#include <string.h>
#include "filesys/free-map.h"
#include "threads/malloc.h"
#include "threads/palloc.h"
#include "threads/vaddr.h"
#include "lib/kernel/bitmap.h"


static struct list storage_list;
static struct lock grow_lock;

struct indirect_inode
  {
    block_sector_t indirect_blocks[INDIRECT_PTR];
  };

/* Returns the number of sectors to allocate for an inode SIZE
   bytes long. */
static inline size_t
bytes_to_sectors (off_t size)
{
  return DIV_ROUND_UP (size, BLOCK_SECTOR_SIZE);
}

/* Returns the block device sector that contains byte offset POS
   within INODE.
   Returns -1 if INODE does not contain data for a byte at offset
   POS. */
static block_sector_t
byte_to_sector (const struct inode *inode, off_t pos) 
{
  // printf("*************BTS****************\n");
  ASSERT (inode != NULL);
  if (pos < inode->data.length) 
  {
    off_t index = pos / BLOCK_SECTOR_SIZE;
    off_t indirect_i = index - PTR_VALUE;
    off_t dindirect_i = index - INDIRECT_SECTOR;
    /* Get the position in the direct inode */
    if(index < PTR_VALUE)
    {
      return inode->data.direct_blocks[index];
    }
    /* Get the position in single indirect inode */
    else if(indirect_i < INDIRECT_PTR) 
    {
      struct indirect_inode ind_inode;
      block_read(fs_device, inode->data.indirect, &ind_inode);
      return ind_inode.indirect_blocks[indirect_i];
    }
    /* Get the position in doubly indirect inode */
    else
    {
      off_t firstlvlIndex = dindirect_i / INDIRECT_PTR;
      off_t secondlvlIndex = dindirect_i % INDIRECT_PTR;
      struct indirect_inode dind_inode;
      struct indirect_inode ind_inode;
      block_read(fs_device, inode->data.double_indirect, &dind_inode);
      block_read(fs_device, dind_inode.indirect_blocks[firstlvlIndex], &ind_inode);
      return ind_inode.indirect_blocks[secondlvlIndex];
    }
  }
  else
    return -1;
}

/* List of open inodes, so that opening a single inode twice
   returns the same `struct inode'. */
static struct list open_inodes;

/* Initializes the inode module. */
void
inode_init (void) 
{
  lock_init (&grow_lock);		
  list_init (&open_inodes);
  list_init (&storage_list);
}

bool
add_indirect(size_t index, struct inode_disk *disk_inode, char *zeros)
{
  struct indirect_inode *ind_inode;
  ind_inode =  calloc (1, BLOCK_SECTOR_SIZE);
  off_t pos = index - PTR_VALUE;

  if(pos == 0)
  {
    if(!free_map_allocate(1, &disk_inode->indirect))
      goto fail;

    block_write(fs_device, disk_inode->indirect, ind_inode);
  }

	block_read(fs_device, disk_inode->indirect, ind_inode);
	if(!free_map_allocate(1, &ind_inode->indirect_blocks[pos]))
	  goto fail;
	block_write (fs_device, ind_inode->indirect_blocks[pos], zeros);
	block_write(fs_device, disk_inode->indirect, ind_inode);

  return true;

fail:
  free(ind_inode);
  return false;
}

bool
add_double_indirect(size_t index, struct inode_disk *disk_inode, char *zeros)
{
  struct indirect_inode *dind_inode, *ind_inode;
  dind_inode =  calloc (1, BLOCK_SECTOR_SIZE);
  ind_inode =  calloc (1, BLOCK_SECTOR_SIZE);
  off_t pos = index - INDIRECT_SECTOR;
  off_t dindirectIndex = pos / INDIRECT_PTR;
  off_t indirectIndex = pos % INDIRECT_PTR;
  if(pos == 0)
  {
    if(!free_map_allocate(1, &disk_inode->double_indirect))
      goto fail;    

    block_write(fs_device, disk_inode->double_indirect, dind_inode);
  }
  block_read(fs_device, disk_inode->double_indirect, dind_inode);

  if(indirectIndex == 0)
  {
    if(!free_map_allocate(1, &dind_inode->indirect_blocks[indirectIndex]))
      goto fail;
      block_read(fs_device, disk_inode->double_indirect, dind_inode);
      block_write(fs_device, dind_inode->indirect_blocks[indirectIndex], ind_inode);
  }

  block_read(fs_device, dind_inode->indirect_blocks[dindirectIndex], ind_inode);
  if(!free_map_allocate(1, &ind_inode->indirect_blocks[indirectIndex]))
    goto fail;
  block_write (fs_device, ind_inode->indirect_blocks[indirectIndex], zeros);
  block_write(fs_device, dind_inode->indirect_blocks[dindirectIndex], ind_inode);
  block_write(fs_device, disk_inode->double_indirect, dind_inode);

  return true;
fail:
  free(ind_inode);
  free(dind_inode);
  return false;
}

/* Extend the inode files to given length */
bool
inode_grow(size_t start, size_t sectors, struct inode_disk *disk_inode, block_sector_t sector)
{
  lock_acquire(&grow_lock);
  static char zeros[BLOCK_SECTOR_SIZE];
  size_t index;
              
  for (index = start; index < sectors; index++) 
  {
      /* Extend the direct inode sectors */
      if(index < PTR_VALUE)
      {
        // printf("************DIRECT************%d\n", index);
        // disk_inode->direct_blocks[index] = block;
        if(!free_map_allocate(1, &disk_inode->direct_blocks[index])) 
        {
        	goto fail;
        }
        block_write (fs_device, disk_inode->direct_blocks[index], zeros);

      }
      /* Extend the indirect inode sectors */
      else if(index < INDIRECT_SECTOR) 
      {
        // printf("************INDIRECT************\n");

        if(!add_indirect(index, disk_inode, zeros))
          goto fail;

      }
      /* Extend doubly indirect inode sectors */
      else if(index < DINDIRECT_SECTOR)
      {
            // printf("************DOUBLEDIRECT************\n");
        if(!add_double_indirect(index, disk_inode, zeros))
          goto fail;

      }
      else {
        // printf("**************WRONG************\n");
        goto fail;
      }
      disk_inode->num_sectors++;
      block_write (fs_device, sector, disk_inode);
  }
  lock_release(&grow_lock);
  return true;

fail:
  lock_release(&grow_lock);
  return false;
}

/* Deleting the inode files achieve from grow */
void
inode_shrink(struct inode *inode)
{
  block_read(fs_device, inode->sector, &inode->data);
  size_t index, end;
  end = inode->data.num_sectors;
   printf("***************SHRINKbytes %d len %d \n", bytes_to_sectors(inode->length), inode->data.length);           
  for (index = 0; index < end; index++) 
  {
      if(index < PTR_VALUE)
      {
        free_map_allocate(&inode->data.direct_blocks[index], 1);
      }
      /* Remove indirect inode sectors */
      else if(index < INDIRECT_SECTOR) 
      {
          struct indirect_inode ind_inode;
          block_read(fs_device, inode->data.indirect, &ind_inode);
          off_t pos = index - PTR_VALUE;

          free_map_allocate(&ind_inode.indirect_blocks[pos], 1);
          if(index == INDIRECT_SECTOR - 1 || index == end)
          {
            free_map_release(&inode->data.indirect, 1);
          }
      }
      /* Remove doubly indirect inode sectors */
      else if(index < DINDIRECT_SECTOR)
      {
        struct indirect_inode dind_inode, ind_inode;
        off_t pos = index - INDIRECT_SECTOR;
        off_t dindirectIndex = pos / INDIRECT_PTR;
        off_t indirectIndex = pos % INDIRECT_PTR;
        block_read(fs_device, inode->data.double_indirect, &dind_inode);
        block_read(fs_device, dind_inode.indirect_blocks[dindirectIndex], &ind_inode);

        free_map_release(&ind_inode.indirect_blocks[indirectIndex], 1);
        if(indirectIndex == INDIRECT_SECTOR -1 || index == end)
        {
          free_map_release(&dind_inode.indirect_blocks[indirectIndex], 1);
        }

        if(index == DINDIRECT_SECTOR -1 || index == end)
        {
          free_map_release(&inode->data.double_indirect, 1);  
        }
      }
      block_write(fs_device, inode->sector, &inode->data);
  }
}

/* Initializes an inode with LENGTH bytes of data and
   writes the new inode to sector SECTOR on the file system
   device.
   Returns true if successful.
   Returns false if memory or disk allocation fails. */
bool
inode_create (block_sector_t sector, off_t length, bool isDir)
{
  // printf("**********CREATE***************\n");
  struct inode_disk *disk_inode = NULL;
  bool success = false;

  ASSERT (length >= 0);

  /* If this assertion fails, the inode structure is not exactly
     one sector in size, and you should fix that. */
  ASSERT (sizeof *disk_inode == BLOCK_SECTOR_SIZE);

  disk_inode = calloc (1, sizeof *disk_inode);
  if (disk_inode != NULL)
    {
      // printf("**************LENGTH = %d\n", length);
      size_t sectors = bytes_to_sectors (length);
      disk_inode->length = length;
      disk_inode->magic = INODE_MAGIC;
      disk_inode->isDir = isDir;
      disk_inode->num_sectors = 0;

      success = inode_grow(0, sectors, disk_inode, sector);
// printf("*************disk_inode %d\n", disk_inode->length );
      block_write (fs_device, sector, disk_inode);

      free (disk_inode);
    }
    // printf("***************%d***********\n", success);
  return success;
}

/* Reads an inode from SECTOR
   and returns a `struct inode' that contains it.
   Returns a null pointer if memory allocation fails. */
struct inode *
inode_open (block_sector_t sector)
{
  // printf("***********OPEN*****************\n");
  struct list_elem *e;
  struct inode *inode;

  /* Check whether this inode is already open. */
  for (e = list_begin (&open_inodes); e != list_end (&open_inodes);
       e = list_next (e)) 
    {
      inode = list_entry (e, struct inode, elem);
      if (inode->sector == sector) 
        {
          inode_reopen (inode);
          return inode; 
        }
    }

  /* Allocate memory. */
  inode = malloc (sizeof *inode);
  if (inode == NULL)
    return NULL;

  /* Initialize. */
  list_push_front (&open_inodes, &inode->elem);
  lock_init(&inode->grow_lock);
  inode->sector = sector;
  inode->open_cnt = 1;
  inode->deny_write_cnt = 0;
  inode->removed = false;
  inode->parent = ROOT_DIR_SECTOR;
  block_read (fs_device, inode->sector, &inode->data);
  inode->num_sectors = inode->data.num_sectors;
  inode->length = inode->data.length;
   // printf("***************OPEnbytes %d len %d \n", bytes_to_sectors(inode->length), inode->data.length);           
  return inode;
}

/* Reopens and returns INODE. */
struct inode *
inode_reopen (struct inode *inode)
{
  if (inode != NULL)
    inode->open_cnt++;
  return inode;
}

/* Returns INODE's inode number. */
block_sector_t
inode_get_inumber (const struct inode *inode)
{
  return inode->sector;
}

int 
inode_get_opencnt(struct inode *inode)
{
  return inode->open_cnt;
}

/* Closes INODE and writes it to disk. (Does it?  Check code.)
   If this was the last reference to INODE, frees its memory.
   If INODE was also a removed inode, frees its blocks. */
void
inode_close (struct inode *inode) 
{
   // printf("****************inodeclose\n");
  /* Ignore null pointer. */
  if (inode == NULL)
    return;

  /* Release resources if this was the last opener. */
  if (--inode->open_cnt == 0)
    {
      /* Remove from inode list and release lock. */
      list_remove (&inode->elem);
 
      /* Deallocate blocks if removed. */
      if (inode->removed) 
        {
          // block_read(fs_device, inode->sector, &inode->data);
          // free_map_release (inode->sector, 1);
// printf("****************inode removed\n");
// printf("***************bytes %d len %d \n", bytes_to_sectors(inode->data.length), inode->data.length);
          off_t index = 0;
          block_sector_t sector;
          if((sector = byte_to_sector (inode, index)) != -1)
            {
              // sector += BLOCK_SECTOR_SIZE;
              free_map_release (sector, 1);
              // index++;
            }
          // inode_shrink(inode);

          free_map_release(inode->sector, 1);
        }
        // else
        // {
        //   struct inode_disk disk_inode = {
        //     .length = inode->data.length,
        //     .magic = INODE_MAGIC,
        //     .indirect = inode->data.indirect,
        //     .double_indirect = inode->data.double_indirect,
        //     .isDir = inode->data.isDir,
        //   };
        //   memcpy(&disk_inode.direct_blocks, &inode->data.direct_blocks,
        //    PTR_VALUE*sizeof(block_sector_t));
        //   block_write(fs_device, inode->sector, &disk_inode);
        // }

      free (inode); 
    }
}

/* Marks INODE to be deleted when it is closed by the last caller who
   has it open. */
void
inode_remove (struct inode *inode) 
{
  ASSERT (inode != NULL);
  inode->removed = true;
}

/* Reads SIZE bytes from INODE into BUFFER, starting at position OFFSET.
   Returns the number of bytes actually read, which may be less
   than SIZE if an error occurs or end of file is reached. */
off_t
inode_read_at (struct inode *inode, void *buffer_, off_t size, off_t offset) 
{
  uint8_t *buffer = buffer_;
  off_t bytes_read = 0;
  uint8_t *bounce = NULL;
  block_read (fs_device, inode->sector, &inode->data);
  // printf("**********sector %d  length %d\n", bytes_to_sectors (inode->data.length), inode->data.length);
  while (size > 0) 
    {
      /* Disk sector to read, starting byte offset within sector. */
      block_sector_t sector_idx = byte_to_sector (inode, offset);
      int sector_ofs = offset % BLOCK_SECTOR_SIZE;

      /* Bytes left in inode, bytes left in sector, lesser of the two. */
      off_t inode_left = inode_length (inode) - offset;
      int sector_left = BLOCK_SECTOR_SIZE - sector_ofs;
      int min_left = inode_left < sector_left ? inode_left : sector_left;

      /* Number of bytes to actually copy out of this sector. */
      int chunk_size = size < min_left ? size : min_left;
      if (chunk_size <= 0)
        break;

      if (sector_ofs == 0 && chunk_size == BLOCK_SECTOR_SIZE)
        {
          /* Read full sector directly into caller's buffer. */
          block_read (fs_device, sector_idx, buffer + bytes_read);
        }
      else 
        {
          /* Read sector into bounce buffer, then partially copy
             into caller's buffer. */
          if (bounce == NULL) 
            {
              bounce = malloc (BLOCK_SECTOR_SIZE);
              if (bounce == NULL)
                break;
            }
          block_read (fs_device, sector_idx, bounce);
          memcpy (buffer + bytes_read, bounce + sector_ofs, chunk_size);
        }
      
      /* Advance. */
      size -= chunk_size;
      offset += chunk_size;
      bytes_read += chunk_size;
    }
  free (bounce);

  return bytes_read;
}

/* Writes SIZE bytes from BUFFER into INODE, starting at OFFSET.
   Returns the number of bytes actually written, which may be
   less than SIZE if end of file is reached or an error occurs.
   (Normally a write at end of file would extend the inode, but
   growth is not yet implemented.) */
off_t
inode_write_at (struct inode *inode, const void *buffer_, off_t size,
                off_t offset) 
{
  const uint8_t *buffer = buffer_;
  off_t bytes_written = 0;
  uint8_t *bounce = NULL;
  off_t length = inode_length(inode);

  if (inode->deny_write_cnt)
    return 0;
  // printf("**********SIZE %d  OFFSET %d\n", size, offset);
  // lock_acquire(&inode->grow_lock);
  if(size + offset > length) 
  {
    size_t start = bytes_to_sectors (length);
    size_t end = bytes_to_sectors (offset + size);

    if(inode_grow(start, end, &inode->data, inode->sector))
    {
      inode->data.length = size + offset;
      inode->length = inode->data.length;
    }

  }

  inode->num_sectors = inode->data.num_sectors;
  // printf("**********inodesector %d  length %d\n", bytes_to_sectors (inode->length), inode->length);
  // lock_release(&inode->grow_lock);
  block_write (fs_device, inode->sector, &inode->data);
  

  while (size > 0) 
    {
      /* Sector to write, starting byte offset within sector. */
      block_sector_t sector_idx = byte_to_sector (inode, offset);
      int sector_ofs = offset % BLOCK_SECTOR_SIZE;

      /* Bytes left in inode, bytes left in sector, lesser of the two. */
      off_t inode_left = inode_length (inode) - offset;
      int sector_left = BLOCK_SECTOR_SIZE - sector_ofs;
      int min_left = inode_left < sector_left ? inode_left : sector_left;

      /* Number of bytes to actually write into this sector. */
      int chunk_size = size < min_left ? size : min_left;
      if (chunk_size <= 0)
        break;

      if (sector_ofs == 0 && chunk_size == BLOCK_SECTOR_SIZE)
        {
          /* Write full sector directly to disk. */
          block_write (fs_device, sector_idx, buffer + bytes_written);
        }
      else 
        {
          /* We need a bounce buffer. */
          if (bounce == NULL) 
            {
              bounce = malloc (BLOCK_SECTOR_SIZE);
              if (bounce == NULL)
                break;
            }

          /* If the sector contains data before or after the chunk
             we're writing, then we need to read in the sector
             first.  Otherwise we start with a sector of all zeros. */
          if (sector_ofs > 0 || chunk_size < sector_left) 
            block_read (fs_device, sector_idx, bounce);
          else
            memset (bounce, 0, BLOCK_SECTOR_SIZE);
          memcpy (bounce + sector_ofs, buffer + bytes_written, chunk_size);
          block_write (fs_device, sector_idx, bounce);
        }

      /* Advance. */
      size -= chunk_size;
      offset += chunk_size;
      bytes_written += chunk_size;
    }
  free (bounce);

  return bytes_written;
}

/* Disables writes to INODE.
   May be called at most once per inode opener. */
void
inode_deny_write (struct inode *inode) 
{
  inode->deny_write_cnt++;
  ASSERT (inode->deny_write_cnt <= inode->open_cnt);
}

/* Re-enables writes to INODE.
   Must be called once by each inode opener who has called
   inode_deny_write() on the inode, before closing the inode. */
void
inode_allow_write (struct inode *inode) 
{
  ASSERT (inode->deny_write_cnt > 0);
  ASSERT (inode->deny_write_cnt <= inode->open_cnt);
  inode->deny_write_cnt--;
}

/* Returns the length, in bytes, of INODE's data. */
off_t
inode_length (const struct inode *inode)
{
  return inode->data.length;
}

bool
inode_isDir (const struct inode *inode)
{
  return inode->data.isDir;
}

block_sector_t 
inode_get_parentdir(const struct inode *inode)
{
  return inode->parent;
}

bool
inode_set_parentdir(block_sector_t child, block_sector_t parent)
{
  struct inode *child_inode = inode_open(child);
  if(child_inode == NULL)
  {
    return false;
  }

  child_inode->parent = parent;
  inode_close(child_inode);
  return true;
}

struct inode *
get_dirinode(struct dir *dir, char *file_name)
{
  // printf("************file_name %s\n", file_name);
  struct inode *inode = NULL; 
  struct inode *child_inode =  dir_get_inode(dir);

   if(strcmp(file_name, "..") == 0)
   {
      block_sector_t parent_sector = inode_get_parentdir(child_inode);
      inode = inode_open(parent_sector);
   }
  else
  {
    dir_lookup(dir, file_name, &inode);
  }

 return inode;
}

void
page_init(struct storage *mem)
{
  int i, blocks_inpage = PGSIZE / BLOCK_SECTOR_SIZE;
  mem->page = palloc_get_page (PAL_ZERO);
  for(i = 0; i < blocks_inpage; i++)
  {
    mem->page += i * BLOCK_SECTOR_SIZE;
  }
}

struct storage *
get_storage (block_sector_t sector) 
{
	struct list_elem *e = list_begin(&storage_list);
	while (e != list_end(&storage_list))
	{
		struct storage *temp = list_entry(e, struct storage, elem);
		if(temp->sector == sector)
		{
			return temp;
		}
		e = list_next(e);
	}
	return NULL;
}

void 
storage_write (block_sector_t sector, const void *buffer, off_t offset, int size)
{
	struct storage *mem = get_storage(sector);
	if(mem == NULL)
	{
		mem = calloc(1, sizeof *mem);
		mem->sector = sector;
		page_init (mem);
    list_push_front(&storage_list, &mem->elem);
	}
	memcpy(mem->page + offset, buffer, size);
}

void
storage_read (block_sector_t sector, const void *buffer, off_t offset, int size)
{
	struct storage *mem = get_storage(sector);
  if(mem == NULL)
  {
    mem = calloc(1, sizeof *mem);
    mem->sector = sector;
    page_init (mem);
    list_push_front(&storage_list, &mem->elem);
  }

  memcpy(buffer, mem->page + offset, size);
}