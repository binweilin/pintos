#include "filesys/filesys.h"
#include <debug.h>
#include <stdio.h>
#include <string.h>
#include "filesys/file.h"
#include "filesys/free-map.h"
#include "filesys/inode.h"
#include "filesys/directory.h"
#include "threads/malloc.h"

/* Partition that contains the file system. */
struct block *fs_device;

static void do_format (void);
bool empty_dir(char *filename);
/* Initializes the file system module.
   If FORMAT is true, reformats the file system. */
void
filesys_init (bool format) 
{
  fs_device = block_get_role (BLOCK_FILESYS);
  if (fs_device == NULL)
    PANIC ("No file system device found, can't initialize file system.");

  inode_init ();
  free_map_init ();
  thread_current()->directory = dir_open_root();

  if (format) 
    do_format ();

  free_map_open ();
}

/* Shuts down the file system module, writing any unwritten data
   to disk. */
void
filesys_done (void) 
{
  free_map_close ();
}

char*
get_file (const char *path_name)
{
  int len = strlen(path_name) + 1;
  char copy[len];
  strlcpy(copy, path_name, len);
  char *save_ptr, *token;

  token = strtok_r(copy, "/", &save_ptr);
  char *name = token;
  while(token != NULL)
  {
    name = token;
    token = strtok_r(NULL, "/", &save_ptr);
  }


  len = strlen(name) + 1;
  char *filename = malloc(len * sizeof(char));
  strlcpy(filename, name, len);
  return filename;
}

bool
isRoot(const char *name)
{
  if(strcmp (name, "/") == 0)
    return true;
  return false;
}


/* Creates a file named NAME with the given INITIAL_SIZE.
   Returns true if successful, false otherwise.
   Fails if a file named NAME already exists,
   or if internal memory allocation fails. */
bool
filesys_create (const char *name, off_t initial_size, bool isDir) 
{
	// printf("**************ISDIR %d \n", isDir);
 //  printf("**************NAME %s\n", name);
  bool success = false;	
  block_sector_t inode_sector = 0;
  struct dir *dir = get_currentdir(name);
  char *filename = get_file(name);
  // printf("**************FILENAME %s\n", filename);
  // printf("**************DIR %d \n", dir);
  if(!empty_dir(filename))
  {
  	success = (dir != NULL
                  && free_map_allocate (1, &inode_sector)
                  && inode_create (inode_sector, initial_size, isDir)
                  && dir_add (dir, filename, inode_sector));
    // if(isDir)
    //   free(filename);
  }
  if (!success && inode_sector != 0) 
    free_map_release (inode_sector, 1);
  dir_close (dir);
  free(filename);
  // printf("******************SUCCCESS %d\n", success);
  return success;
}

/* Opens the file with the given NAME.
   Returns the new file if successful or a null pointer
   otherwise.
   Fails if no file named NAME exists,
   or if an internal memory allocation fails. */
struct file *
filesys_open (const char *name)
{
  // printf("**************OPENNAME %s\n", name);
  struct dir *dir = get_currentdir(name);
  char *filename = get_file(name);

  if (dir != NULL )
  {
    if((root_dir(dir) && !strlen(filename)))
    {
     // printf("**************RetDIR %d \n", dir);
      return file_open(dir->inode);
    }
              // printf("**************DIR %d \n", dir);
    struct inode *open_inode = get_dirinode(dir, filename);

  // printf("**************NAME %s\n", filename);
    dir_close (dir);
      // printf("**************HERE %s\n", filename);
    if(filename != NULL)
      free(filename);

      // printf("**************FREE %s\n");
    if(open_inode != NULL)
            // printf("**************FREE %s\n");
      return file_open (open_inode);
  }
              // printf("**************NULLL %s\n");
  return NULL;
}

/* Deletes the file named NAME.
   Returns true if successful, false on failure.
   Fails if no file named NAME exists,
   or if an internal memory allocation fails. */
bool
filesys_remove (const char *name) 
{
  // printf("**************REMOVE %s \n", name);
  struct dir *dir = get_currentdir(name);
  char* filename = get_file(name);
  // struct dir *dir = dir_open_root();
  bool success = false;
  if(dir != NULL )
  {
    if((dir == thread_current()->directory))
    {
      return false;
    }
    success = dir_remove (dir, filename);
  }

  dir_close (dir); 
  free(filename);

 // printf("**************success %d \n", success);
  return success;
}

/* Formats the file system. */
static void
do_format (void)
{
  printf ("Formatting file system...");
  free_map_create ();
  if (!dir_create (ROOT_DIR_SECTOR, 16))
    PANIC ("root directory creation failed");
  free_map_close ();
  printf ("done.\n");
}

bool
empty_dir(char *filename)
{
	return (strcmp(filename, ".") == 0) || (strcmp(filename, "..") == 0);
}